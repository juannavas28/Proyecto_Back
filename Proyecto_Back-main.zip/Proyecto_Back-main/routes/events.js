const express = require("express");
const router = express.Router();

const { 
  createEvent, 
  updateEvent, 
  getAllEvents, 
  getEventById, 
  searchEvents, 
  deleteEvent,
  getMyEvents,
  submitEventForApproval,
  listPendingReview,
  approveEvent,
  rejectEvent
} = require("../controllers/eventController");

const { authenticateToken, requireRole } = require("../middleware/auth");
const { validateEventData } = require("../middleware/validation");

// HU1.1 - Registro de evento
router.post(
  "/",
  authenticateToken,
  requireRole(["DOCENTE", "SECRETARIO"]),
  validateEventData,
  createEvent
);

// HU1.2 - Actualización de evento
router.put(
  "/:id",
  authenticateToken,
  requireRole(["DOCENTE", "SECRETARIO"]),
  updateEvent
);

// HU1.3 - Obtener todos los eventos
router.get("/", authenticateToken, getAllEvents);

// S2 HU1.4 - Listado de eventos del organizador
router.get("/mis", authenticateToken, getMyEvents);

// HU1.4 - Obtener evento por ID
router.get("/:id", authenticateToken, getEventById);

// HU1.5 - Buscar eventos
router.get("/buscar/filtro", authenticateToken, searchEvents);

// HU1.6 - Eliminar evento
router.delete(
  "/:id",
  authenticateToken,
  requireRole(["DOCENTE", "SECRETARIO"]),
  deleteEvent
);

// S2 HU1.5 - Enviar evento a validación
router.post(
  "/:id/enviar",
  authenticateToken,
  requireRole(["DOCENTE", "SECRETARIO"]),
  submitEventForApproval
);

// S2 HU4.1 - Visualización de pendientes de evaluación (SECRETARIO)
router.get(
  "/pendientes",
  authenticateToken,
  requireRole(["SECRETARIO"]),
  listPendingReview
);

// S2 - Aprobar/Rechazar evento (SECRETARIO)
router.post(
  "/:id/aprobar",
  authenticateToken,
  requireRole(["SECRETARIO"]),
  approveEvent
);
router.post(
  "/:id/rechazar",
  authenticateToken,
  requireRole(["SECRETARIO"]),
  rejectEvent
);

module.exports = router;
