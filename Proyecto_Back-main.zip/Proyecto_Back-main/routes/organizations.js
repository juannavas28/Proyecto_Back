﻿const express = require("express");
const router = express.Router();
// Ya no se requiere subida de PDF aquí según el esquema actual

const {
  createOrganization,
  searchOrganizations,
  getOrganizationById,
  updateOrganization,
  deleteOrganization
} = require("../controllers/organizationController");

const { validateOrganizationData } = require("../middleware/validation");
const { authenticateToken, requireRole } = require("../middleware/auth");

// Eliminado multer: no se adjunta certificado en organizaciones_externas

// HU2.1 - Registro de organizaciÃ³n externa
router.post(
  "/",
  authenticateToken,
  requireRole(["SECRETARIO"]),
  validateOrganizationData,
  createOrganization
);

// HU2.2 - BÃºsqueda de organizaciÃ³n externa
router.get("/search", authenticateToken, searchOrganizations);


// HU2.3 - VisualizaciÃ³n de datos de organizaciÃ³n externa
router.get("/:id", authenticateToken, getOrganizationById);

// HU2.4 - EdiciÃ³n de organizaciÃ³n externa
router.put(
  "/:id",
  authenticateToken,
  requireRole(["SECRETARIO"]),
  validateOrganizationData,
  updateOrganization
);

// HU2.5 - EliminaciÃ³n de organizaciÃ³n externa
router.delete("/:id", authenticateToken, requireRole(["SECRETARIO"]), deleteOrganization);

module.exports = router;