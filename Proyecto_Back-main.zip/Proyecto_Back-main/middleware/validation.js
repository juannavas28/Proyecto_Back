// Middleware para validar datos de entrada
const validateCorreo = (correo) => {
  const correoRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return correoRegex.test(correo);
};

const validateRequired = (data, requiredFields) => {
  const missing = [];
  
  for (const field of requiredFields) {
    if (!data[field] || (typeof data[field] === 'string' && data[field].trim() === '')) {
      missing.push(field);
    }
  }
  
  return missing;
};

// Middleware para validar datos de usuario
const validateUserData = (req, res, next) => {
  const { correo, contraseña } = req.body;
  const errors = [];

  if (!correo || !validateCorreo(correo)) {
    errors.push('correo inválido');
  }

  if (!contraseña || contraseña.length < 6) {
    errors.push('La contraseña debe tener al menos 6 caracteres');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Datos de entrada inválidos',
      errors
    });
  }

  next();
};

// Middleware para validar datos de organización
const validateOrganizationData = (req, res, next) => {
  const { nombre, correo, telefono, direccion } = req.body;
  const errors = [];

  if (!nombre || nombre.trim().length < 2) {
    errors.push('El nombre debe tener al menos 2 caracteres');
  }

  if (correo && !validateCorreo(correo)) {
    errors.push('correo inválido');
  }

  if (telefono && telefono.length < 7) {
    errors.push('Teléfono inválido');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Datos de organización inválidos',
      errors
    });
  }

  next();
};

// Middleware para validar datos de evento
const validateEventData = (req, res, next) => {
  const { nombre_evento, descripcion, fecha_inicio, fecha_fin, ubicacion } = req.body;
  const errors = [];

  if (!nombre_evento || nombre_evento.trim().length < 3) {
    errors.push('El nombre debe tener al menos 3 caracteres');
  }

  if (!descripcion || descripcion.trim().length < 10) {
    errors.push('La descripción debe tener al menos 10 caracteres');
  }

  if (!fecha_inicio) {
    errors.push('La fecha de inicio es requerida');
  }

  if (!fecha_fin) {
    errors.push('La fecha de fin es requerida');
  }

  if (fecha_inicio && fecha_fin && new Date(fecha_inicio) >= new Date(fecha_fin)) {
    errors.push('La fecha de inicio debe ser anterior a la fecha de fin');
  }

  if (!ubicacion || ubicacion.trim().length < 3) {
    errors.push('La ubicación debe tener al menos 3 caracteres');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Datos de evento inválidos',
      errors
    });
  }

  next();
};

// Middleware para validar datos de registro de usuario
const validateUserRegistrationData = (req, res, next) => {
  const { correo, contraseña, nombre, telefono, rol } = req.body;
  const errors = [];

  if (!correo || !validateCorreo(correo)) {
    errors.push('Correo inválido');
  }

  if (!contraseña || contraseña.length < 6) {
    errors.push('La contraseña debe tener al menos 6 caracteres');
  }

  if (!nombre || nombre.trim().length < 2) {
    errors.push('El nombre debe tener al menos 2 caracteres');
  }

  if (telefono && telefono.length < 7) {
    errors.push('Teléfono inválido');
  }

  if (rol && !['DOCENTE', 'ESTUDIANTE', 'SECRETARIO'].includes(rol)) {
    errors.push('Rol inválido. Debe ser "DOCENTE", "SECRETRIO" o "ESTUDIANTE"');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Datos de registro inválidos',
      errors
    });
  }

  next();
};

// Middleware para validar datos de actualización de perfil de usuario
const validateUserProfileData = (req, res, next) => {
  const { correo, nombre, telefono } = req.body;
  const errors = [];

  if (correo && !validateCorreo(correo)) {
    errors.push('Correo inválido');
  }

  if (nombre !== undefined && (!nombre || nombre.trim().length < 2)) {
    errors.push('El nombre debe tener al menos 2 caracteres');
  }

  if (telefono && telefono.length < 7) {
    errors.push('Teléfono inválido');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Datos de perfil inválidos',
      errors
    });
  }

  next();
};

// Middleware para validar solicitud de recuperación de contraseña
const validateForgotContraseñaData = (req, res, next) => {
  const { correo } = req.body;
  const errors = [];

  if (!correo || !validateCorreo(correo)) {
    errors.push('Correo inválido');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Correo requerido',
      errors
    });
  }

  next();
};

// Middleware para validar restablecimiento de contraseña
const validateResetContraseñaData = (req, res, next) => {
  const { token, newContraseña } = req.body;
  const errors = [];

  if (!token || token.trim().length === 0) {
    errors.push('Token requerido');
  }

  if (!newContraseña || newContraseña.length < 6) {
    errors.push('La nueva contraseña debe tener al menos 6 caracteres');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Datos de restablecimiento inválidos',
      errors
    });
  }

  next();
};

// Middleware para validar datos de creación de evento
const validateEventCreationData = (req, res, next) => {
  const { nombre_evento, descripcion, fecha_inicio, fecha_fin, ubicacion } = req.body;
  const errors = [];

  if (!nombre_evento || nombre_evento.trim().length < 3) {
    errors.push('El nombre debe tener al menos 3 caracteres');
  }

  if (!descripcion || descripcion.trim().length < 10) {
    errors.push('La descripción debe tener al menos 10 caracteres');
  }

  if (!fecha_inicio) {
    errors.push('La fecha de inicio es requerida');
  }

  if (!fecha_fin) {
    errors.push('La fecha de fin es requerida');
  }

  if (fecha_inicio && fecha_fin && new Date(fecha_inicio) >= new Date(fecha_fin)) {
    errors.push('La fecha de inicio debe ser anterior a la fecha de fin');
  }

  if (!ubicacion || ubicacion.trim().length < 3) {
    errors.push('La ubicación debe tener al menos 3 caracteres');
  }


  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Datos de evento inválidos',
      errors
    });
  }

  next();
};

module.exports = {
  validateCorreo,
  validateRequired,
  validateUserData,
  validateUserRegistrationData,
  validateUserProfileData,
  validateForgotContraseñaData,
  validateResetContraseñaData,
  validateOrganizationData,
  validateEventData,
  validateEventCreationData
};

