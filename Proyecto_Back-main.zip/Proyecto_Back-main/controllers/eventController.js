const { executeQuery } = require('../db');

// HU1.1 - Registro de evento
const createEvent = async (req, res) => {
  console.log("===== DEPURACIÓN createEvent =====");
  console.log("req.user:", req.user);
  console.log("req.body:", req.body);

  try {
    const {
      nombre_evento,
      descripcion,
      tipo,
      fecha_inicio,
      fecha_fin,
      ubicacion
    } = req.body;

    if (!nombre_evento || !descripcion || !tipo || !fecha_inicio || !fecha_fin || !ubicacion) {
      return res.status(400).json({
        success: false,
        message: "Faltan campos requeridos para crear el evento."
      });
    }

    const insertQuery = `
      INSERT INTO eventos 
      (nombre_evento, descripcion, tipo, fecha_inicio, fecha_fin, ubicacion, estado, creado_por)
      VALUES (?, ?, ?, ?, ?, ?, 'borrador', ?)
    `;

    const result = await executeQuery(insertQuery, [
      nombre_evento,
      descripcion,
      tipo,
      fecha_inicio,
      fecha_fin,
      ubicacion,
      (req.user?.userId ?? null)
    ]);

    res.status(201).json({
      success: true,
      message: "Evento creado correctamente.",
      eventId: result.insertId
    });

  } catch (error) {
    console.error("Error creando evento:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: process.env.NODE_ENV === "development" ? error.message : undefined
    });
  }
};

// HU1.2 - Actualización de evento
const updateEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      nombre_evento,
      descripcion,
      tipo,
      fecha_inicio,
      fecha_fin,
      ubicacion,
      estado
    } = req.body;

    const checkQuery = 'SELECT id, estado, creado_por FROM eventos WHERE id = ?';
    const existing = await executeQuery(checkQuery, [id]);

    if (existing.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Evento no encontrado.'
      });
    }

    // Permitir edición sólo en BORRADOR (antes de enviar a validación)
    if (existing[0].estado !== 'borrador') {
      return res.status(400).json({ success: false, message: 'Sólo se puede editar un evento en borrador.' });
    }
    // Si no es secretario, debe ser el creador
    if (req.user?.rol !== 'SECRETARIO' && existing[0].creado_por !== req.user?.userId) {
      return res.status(403).json({ success: false, message: 'No autorizado para editar este evento.' });
    }

    const updateFields = [];
    const updateParams = [];

    if (nombre_evento !== undefined) {
      updateFields.push('nombre_evento = ?');
      updateParams.push(nombre_evento);
    }
    if (descripcion !== undefined) {
      updateFields.push('descripcion = ?');
      updateParams.push(descripcion);
    }
    if (tipo !== undefined) {
      updateFields.push('tipo = ?');
      updateParams.push(tipo);
    }
    if (fecha_inicio !== undefined) {
      updateFields.push('fecha_inicio = ?');
      updateParams.push(fecha_inicio);
    }
    if (fecha_fin !== undefined) {
      updateFields.push('fecha_fin = ?');
      updateParams.push(fecha_fin);
    }
    if (ubicacion !== undefined) {
      updateFields.push('ubicacion = ?');
      updateParams.push(ubicacion);
    }
    if (estado !== undefined) {
      updateFields.push('estado = ?');
      updateParams.push(estado);
    }

    if (updateFields.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No se proporcionaron campos para actualizar.'
      });
    }

    updateParams.push(id);
    const updateQuery = `
      UPDATE eventos 
      SET ${updateFields.join(', ')}
      WHERE id = ?
    `;

    await executeQuery(updateQuery, updateParams);

    res.status(200).json({
      success: true,
      message: 'Evento actualizado exitosamente.'
    });

  } catch (error) {
    console.error('Error actualizando evento:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// HU1.3 - Obtener todos los eventos
const getAllEvents = async (req, res) => {
  try {
    const query = `
      SELECT * 
      FROM eventos
      ORDER BY fecha_inicio ASC
    `;
    const events = await executeQuery(query);

    res.status(200).json({
      success: true,
      data: { events, total: events.length }
    });
  } catch (error) {
    console.error('Error obteniendo eventos:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};

// HU1.4 - Obtener evento por ID
const getEventById = async (req, res) => {
  try {
    const { id } = req.params;
    const query = `SELECT * FROM eventos WHERE id = ?`;
    const result = await executeQuery(query, [id]);

    if (result.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Evento no encontrado.'
      });
    }

    res.status(200).json({
      success: true,
      data: result[0]
    });

  } catch (error) {
    console.error('Error obteniendo evento por ID:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};

// HU1.5 - Buscar eventos por nombre o tipo
const searchEvents = async (req, res) => {
  try {
    const { nombre_evento, tipo } = req.query;
    let query = `
      SELECT * FROM eventos
      WHERE 1=1
    `;
    const params = [];

    if (nombre_evento) {
      query += ' AND nombre_evento LIKE ?';
      params.push(`%${nombre_evento}%`);
    }

    if (tipo) {
      query += ' AND tipo = ?';
      params.push(tipo);
    }

    query += ' ORDER BY fecha_inicio ASC';

    const events = await executeQuery(query, params);

    res.status(200).json({
      success: true,
      data: { events, total: events.length }
    });

  } catch (error) {
    console.error('Error buscando eventos:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};

// HU1.6 - Eliminar evento
const deleteEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const checkQuery = 'SELECT id, estado, creado_por FROM eventos WHERE id = ?';
    const existing = await executeQuery(checkQuery, [id]);

    if (existing.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Evento no encontrado.'
      });
    }

    // Sólo borrar si está en borrador y es el creador (o secretario)
    if (existing[0].estado !== 'borrador' && req.user?.rol !== 'SECRETARIO') {
      return res.status(400).json({ success: false, message: 'Sólo se puede eliminar eventos en borrador.' });
    }
    if (req.user?.rol !== 'SECRETARIO' && existing[0].creado_por !== req.user?.userId) {
      return res.status(403).json({ success: false, message: 'No autorizado para eliminar este evento.' });
    }
    const deleteQuery = 'DELETE FROM eventos WHERE id = ?';
    await executeQuery(deleteQuery, [id]);

    res.status(200).json({
      success: true,
      message: 'Evento eliminado correctamente.'
    });

  } catch (error) {
    console.error('Error eliminando evento:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};

// SPRINT 2 - HU1.4 Listado de eventos del organizador
const getMyEvents = async (req, res) => {
  try {
    const userId = req.user?.userId;
    const query = `
      SELECT * FROM eventos
      WHERE creado_por = ?
      ORDER BY fecha_inicio ASC
    `;
    const events = await executeQuery(query, [userId]);
    res.status(200).json({ success: true, data: { events, total: events.length } });
  } catch (error) {
    console.error('Error listando mis eventos:', error);
    res.status(500).json({ success: false, message: 'Error interno del servidor' });
  }
};

// SPRINT 2 - HU1.5 Envío de evento a validación/aprobación (cambia a pendiente_revision)
const submitEventForApproval = async (req, res) => {
  try {
    const { id } = req.params;
    const checkQuery = 'SELECT id, estado, creado_por FROM eventos WHERE id = ?';
    const existing = await executeQuery(checkQuery, [id]);
    if (existing.length === 0) {
      return res.status(404).json({ success: false, message: 'Evento no encontrado.' });
    }
    if (existing[0].estado !== 'borrador') {
      return res.status(400).json({ success: false, message: 'Sólo se puede enviar a validación desde borrador.' });
    }
    if (req.user?.rol !== 'SECRETARIO' && existing[0].creado_por !== req.user?.userId) {
      return res.status(403).json({ success: false, message: 'No autorizado para enviar este evento.' });
    }
    const updateQuery = `UPDATE eventos SET estado = 'pendiente_revision' WHERE id = ?`;
    await executeQuery(updateQuery, [id]);
    res.status(200).json({ success: true, message: 'Evento enviado a validación.' });
  } catch (error) {
    console.error('Error enviando a validación:', error);
    res.status(500).json({ success: false, message: 'Error interno del servidor' });
  }
};

// SPRINT 2 - HU4.1 Visualización de pendientes de evaluación (SECRETARIO)
const listPendingReview = async (req, res) => {
  try {
    const query = `SELECT * FROM eventos WHERE estado = 'pendiente_revision' ORDER BY fecha_inicio ASC`;
    const events = await executeQuery(query);
    res.status(200).json({ success: true, data: { events, total: events.length } });
  } catch (error) {
    console.error('Error listando pendientes:', error);
    res.status(500).json({ success: false, message: 'Error interno del servidor' });
  }
};

// SPRINT 2 - Aprobar o rechazar (SECRETARIO) y registrar evaluación
const approveEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const { justificacion } = req.body;
    const checkQuery = 'SELECT id, estado FROM eventos WHERE id = ?';
    const existing = await executeQuery(checkQuery, [id]);
    if (existing.length === 0) {
      return res.status(404).json({ success: false, message: 'Evento no encontrado.' });
    }
    if (existing[0].estado !== 'pendiente_revision') {
      return res.status(400).json({ success: false, message: 'El evento no está pendiente de revisión.' });
    }
    await executeQuery('UPDATE eventos SET estado = \"aprobado\" WHERE id = ?', [id]);
    await executeQuery(
      'INSERT INTO evaluaciones (evento_id, evaluado_por, resultado, justificacion) VALUES (?, ?, \"APROBADO\", ?)',
      [id, req.user.userId, justificacion ?? null]
    );
    res.status(200).json({ success: true, message: 'Evento aprobado.' });
  } catch (error) {
    console.error('Error aprobando evento:', error);
    res.status(500).json({ success: false, message: 'Error interno del servidor' });
  }
};

const rejectEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const { justificacion } = req.body;
    const checkQuery = 'SELECT id, estado FROM eventos WHERE id = ?';
    const existing = await executeQuery(checkQuery, [id]);
    if (existing.length === 0) {
      return res.status(404).json({ success: false, message: 'Evento no encontrado.' });
    }
    if (existing[0].estado !== 'pendiente_revision') {
      return res.status(400).json({ success: false, message: 'El evento no está pendiente de revisión.' });
    }
    await executeQuery('UPDATE eventos SET estado = \"rechazado\" WHERE id = ?', [id]);
    await executeQuery(
      'INSERT INTO evaluaciones (evento_id, evaluado_por, resultado, justificacion) VALUES (?, ?, \"RECHAZADO\", ?)',
      [id, req.user.userId, justificacion ?? null]
    );
    res.status(200).json({ success: true, message: 'Evento rechazado.' });
  } catch (error) {
    console.error('Error rechazando evento:', error);
    res.status(500).json({ success: false, message: 'Error interno del servidor' });
  }
};

module.exports = {
  createEvent,
  updateEvent,
  getAllEvents,
  getEventById,
  searchEvents,
  deleteEvent,
  getMyEvents,
  submitEventForApproval,
  listPendingReview,
  approveEvent,
  rejectEvent
};
