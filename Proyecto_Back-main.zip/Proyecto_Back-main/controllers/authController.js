const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { executeQuery } = require('../db');

// HU3.1 - Registro de usuarios
const registerUser = async (req, res) => {
  try {
    const { correo, contraseña, nombre, apellido, telefono, rol = 'ESTUDIANTE' } = req.body;

    // Validación de campos requeridos (evitar undefined en SQL)
    if (!correo || !contraseña || !nombre || !apellido) {
      return res.status(400).json({
        success: false,
        message: 'Faltan campos requeridos: correo, contraseña, nombre, apellido'
      });
    }

    // Verificar si ya existe un usuario con el mismo email
    const checkQuery = 'SELECT id FROM usuarios WHERE correo = ?';
    const existing = await executeQuery(checkQuery, [correo]);
    if (existing.length > 0) {
      return res.status(409).json({
        success: false,
        message: 'Ya existe un usuario con ese correo'
      });
    }

    // Encriptar contraseña
    const saltRounds = 10;
    const hashedContraseña = await bcrypt.hash(contraseña, saltRounds);

    // Insertar nuevo usuario
    const insertQuery = `
  INSERT INTO usuarios 
  (correo, contraseña, nombre, apellido, telefono, rol, activo, fecha_registro)
  VALUES (?, ?, ?, ?, ?, ?, 1, NOW())
`;


    // Validación/normalización de rol (según esquema de BD)
    const allowedRoles = ['DOCENTE', 'ESTUDIANTE', 'SECRETARIO'];
    const rolUpper = typeof rol === 'string' ? rol.toUpperCase() : 'ESTUDIANTE';
    const rolSeguro = allowedRoles.includes(rolUpper) ? rolUpper : 'ESTUDIANTE';

    const result = await executeQuery(insertQuery, [
      correo,
      hashedContraseña,
      nombre,
      apellido,
      (telefono ?? null),
      rolSeguro
    ]);

    // Obtener el usuario creado (sin contraseña)
    const newUserQuery = `
      SELECT id, correo, nombre, apellido, telefono, rol
      FROM usuarios 
      WHERE id = ?
    `;
    const newUser = await executeQuery(newUserQuery, [result.insertId]);

    res.status(201).json({
      success: true,
      message: 'Usuario registrado exitosamente',
      data: {
        user: newUser[0]
      }
    });

  } catch (error) {
    console.error('Error registrando usuario:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};

// HU3.2 - Autenticación de usuarios (login con email/password)
const loginUser = async (req, res) => {
  try {
    const { correo, contraseña } = req.body;

    const userQuery = `
      SELECT id, correo, contraseña, nombre, apellido, rol, telefono
      FROM usuarios 
      WHERE correo = ? AND activo = 1
    `;
    const users = await executeQuery(userQuery, [correo]);

    if (users.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Credenciales inválidas'
      });
    }

    const user = users[0];
    const isContraseñaValid = await bcrypt.compare(contraseña, user.contraseña);
    if (!isContraseñaValid) {
      return res.status(401).json({
        success: false,
        message: 'Credenciales inválidas'
      });
    }

    const token = jwt.sign(
      { userId: user.id, correo: user.correo, rol: user.rol },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
    );

    res.status(200).json({
      success: true,
      message: 'Login exitoso',
      data: {
        token,
        user: {
          id: user.id,
          correo: user.correo,
          nombre: user.nombre,
          apellido: user.apellido,
          rol: user.rol
        }
      }
    });

  } catch (error) {
    console.error('Error en login:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};

// HU3.3 - Obtener usuario actual
const getCurrentUser = async (req, res) => {
  try {
    const userQuery = `
      SELECT id, correo, nombre, apellido, rol, telefono
      FROM usuarios 
      WHERE id = ? AND activo = 1
    `;
    const users = await executeQuery(userQuery, [req.user.userId]);

    if (users.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado'
      });
    }

    res.status(200).json({
      success: true,
      data: { user: users[0] }
    });

  } catch (error) {
    console.error('Error obteniendo usuario actual:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};
// HU3.3 - Actualizar perfil
const updateProfile = async (req, res) => {
  try {
    let { nombre, apellido, telefono, correo } = req.body;
    const userId = req.user?.userId; // ID desde el token JWT

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: "No se pudo identificar al usuario desde el token",
      });
    }

    // Evitar undefined → usar null
    nombre = nombre ?? null;
    apellido = apellido ?? null;
    telefono = telefono ?? null;
    correo = correo ?? null;

    console.log("📨 Datos recibidos:", { nombre, apellido, telefono, correo, userId });

    const updateQuery = `
      UPDATE usuarios
      SET nombre = ?, apellido = ?, telefono = ?, correo = ?, fecha_actualizacion = NOW()
      WHERE id = ?
    `;

    await executeQuery(updateQuery, [nombre, apellido, telefono, correo, userId]);

    res.status(200).json({
      success: true,
      message: "Perfil actualizado exitosamente",
    });
  } catch (error) {
    console.error("Error actualizando perfil:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// HU3.4 - Recuperación de credenciales (genera token de reseteo firmado)
const forgotContraseña = async (req, res) => {
  try {
    const { correo } = req.body;
    if (!correo) {
      return res.status(400).json({ success: false, message: 'Correo es requerido' });
    }
    const findUserQuery = 'SELECT id, correo FROM usuarios WHERE correo = ? AND activo = 1';
    const users = await executeQuery(findUserQuery, [correo]);
    if (users.length === 0) {
      // No revelar si existe o no
      return res.status(200).json({ success: true, message: 'Si el correo existe, se enviará un enlace de recuperación' });
    }
    const user = users[0];
    const resetToken = jwt.sign(
      { userId: user.id, action: 'reset_password' },
      process.env.JWT_SECRET,
      { expiresIn: '30m' }
    );
    // En un entorno real se enviaría por correo. Para pruebas devolvemos el token.
    return res.status(200).json({ success: true, message: 'Token de reseteo generado', data: { resetToken } });
  } catch (error) {
    console.error('Error en forgotContraseña:', error);
    return res.status(500).json({ success: false, message: 'Error interno del servidor' });
  }
};

// HU3.4 - Reset de contraseña usando token
const resetContraseña = async (req, res) => {
  try {
    const { token, nuevaContraseña } = req.body;
    if (!token || !nuevaContraseña) {
      return res.status(400).json({ success: false, message: 'Token y nuevaContraseña son requeridos' });
    }
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded.action !== 'reset_password') {
      return res.status(400).json({ success: false, message: 'Token inválido' });
    }
    const saltRounds = 10;
    const hashed = await bcrypt.hash(nuevaContraseña, saltRounds);
    const updatePwdQuery = 'UPDATE usuarios SET contraseña = ?, fecha_actualizacion = NOW() WHERE id = ?';
    await executeQuery(updatePwdQuery, [hashed, decoded.userId]);
    return res.status(200).json({ success: true, message: 'Contraseña actualizada' });
  } catch (error) {
    console.error('Error en resetContraseña:', error);
    return res.status(500).json({ success: false, message: 'Error interno del servidor' });
  }
};

// HU3.5 - Cierre de sesión
const logoutUser = async (req, res) => {
  res.json({ success: true, message: "Sesión cerrada exitosamente" });
};

module.exports = {
  registerUser,
  loginUser,
  getCurrentUser,
  updateProfile,
  forgotContraseña,
  resetContraseña,
  logoutUser
};
